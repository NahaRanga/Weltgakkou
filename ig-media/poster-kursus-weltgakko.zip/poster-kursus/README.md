# Poster kursus Weltgakko (6 Nov 2026)

9 PNG 1080x1350 (4:5) + 2 kolase. Urutan carousel/kolase: 00 cover di tengah kolase.

| File | Isi | Harga | CTA |
|---|---|---|---|
| 00-cover | Hook "Kamu mau mulai dari level mana?" | - | weltgakko.com |
| 01-n5-regular | Batch 1 mulai Sen 16 Nov, tutup Min 15 Nov 23.59 | Rp600rb/bln atau Rp1,5jt lunas | /program/jlpt-n5 |
| 02-n4-regular | waiting list, tes penempatan | Rp650rb/bln atau Rp1,8jt lunas | /program/jlpt-n4 |
| 03-n3-regular | waiting list, 6 bulan | Rp800rb/bln atau Rp4,5jt lunas | /program/jlpt-n3 |
| 04-jerman-a1-regular | waiting list, Sen–Kam 90 menit | Rp700rb/bln x 3 bln (Rp2,1jt) | /program/jerman-a1 |
| 05–08 private N5/N4/N3/A1 | 1-on-1, jadwal bebas | BELUM ADA, tertulis "Harga & jadwal? Chat admin dulu." | WA 0882-9403-4285, ketik PRIVATE xx |

Sumber harga: src/lib/programs.ts (N5/N4/N3), keputusan winata 4 Nov (A1 Rp700rb/bln). Harga Private belum pernah diputuskan.
Kalau harga Private sudah ada: isi PRIVATE_PRICE di _sumber/build.py, lalu `python3 build.py && node render.js`, kolase dibuat ulang (lihat potongan PIL di riwayat thread, atau minta Claude).

Cek sebelum iklan: Nurdin cek あいうえお (N5); pengajar A1 & Private belum pasti; N4/A1 masih waiting list (rencana Des, belum final).

Caption usulan (kolase/carousel):
Jepang N5 sampai N3, plus Jerman A1. Mau kelas rame-rame maks 15 orang atau berdua sama guru? Geser buat lihat harga tiap kelas.
Batch 1 JLPT N5 mulai Senin 16 Nov, daftar di weltgakko.com. Kelas private: chat admin di WA 0882-9403-4285.
#belajarbahasajepang #jlptn5 #bahasajerman
